#pragma once

#include "basic.h"

void circle_points(int x, int y, int cx, int cy) {
	glBegin(GL_POINTS);
	glVertex2i(x + cx, y + cy); glVertex2i(y + cx, x + cy);
	glVertex2i(-x + cx, y + cy); glVertex2i(y + cx, -x + cy);
	glVertex2i(x + cx, -y + cy); glVertex2i(-y + cx, x + cy);
	glVertex2i(-x + cx, -y + cy); glVertex2i(-y + cx, -x + cy);
	glEnd();
	glFlush();
}

void midpoint_circle(int cx, int cy, int r) {  //Բ�η�ԭ�㣬���������ƽ��
	int x, y;
	float d;
	x = 0;
	y = r;
	d = 1.25 - r;
	circle_points(x, y, cx, cy);
	while (x <= y) {
		if (d < 0) {
			d = d + 2 * x + 3;
		}
		else {
			d = d + 2 * (x - y) + 5;
			y--;
		}
		x++;
		circle_points(x, y, cx, cy);
	}
}

void bresenham_cricle(int cx, int cy, int r) {
	int x, y;
	int d;
	x = 0;
	y = r;
	d = 3 - 2 * r;
	circle_points(x, y, cx, cy);
	while (x <= y) {
		if (d < 0) {
			d = d + 4 * x + 6;
		}
		else {
			d = d + 4 * (x - y) + 10;
			y--;
		}
		x++;
		circle_points(x, y, cx, cy);
	}
}



void display_cricle(void) {
	glClear(GL_COLOR_BUFFER_BIT);
	glColor3f(0.0, 0.0, 0.0);
	glPointSize(2);
	int cx = 260, cy = 540, r = 200;
	midpoint_circle(cx, cy, r);
	bresenham_cricle(cx + 500, cy, r);
}
