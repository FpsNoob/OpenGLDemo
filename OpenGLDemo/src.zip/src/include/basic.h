#pragma once

#include <iostream>
#include <gl/GLUT.H>
#include <cmath>
#include <time.h>
using namespace std;

