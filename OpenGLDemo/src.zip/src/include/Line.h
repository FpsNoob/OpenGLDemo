#pragma once
#include "basic.h"

void dda_line(int x0, int y0, int x1, int y1)
{
	float x, y, k;
	float dx = x1 - x0, dy = y1 - y0;
	int cx = dx > 0 ? 1 : -1;
	int cy = dy > 0 ? 1 : -1;
	float ux = dx > 0 ? 0.5 : -0.5;
	float uy = dy > 0 ? 0.5 : -0.5;
	k = dy*1.0 / dx;
	if (fabs(k) <= 1) {
		if (dx < 0) {
			k = -k;
		}
		y = y0;
		for (x = x0; x != x1; x += cx) {
			glBegin(GL_POINTS); //GL_POINTS������
			glVertex2i((int)x, (int)(y+uy));
			glEnd();
			glFlush();
			y = y + k;
		}
	}
	else {
		if (dy < 0) {
			k = -k;
		}
		x = x0;
		for (y = y0; y != y1; y += cy) {
			glBegin(GL_POINTS); //GL_POINTS������
			glVertex2i((int)(x+ux), (int)y);
			glEnd();
			glFlush();
			x = x + 1.0 / k;
		}
	}
}

void midpoint_line(int x0, int y0, int x1, int y1)
{
	int a = y0 - y1;
	int b = x1 - x0;
	int cx = (b >= 0 ? 1 : (b = -b, -1));
	int cy = (a <= 0 ? 1 : (a = -a, -1));
	int x = x0;
	int y = y0;
	glBegin(GL_POINTS);
	glVertex2i(x, y);
	glEnd();
	glFlush();
	int d, d1, d2;
	if (abs(a) <= abs(b)) {  //б�ʾ���ֵ<=1
		d = 2 * a + b;
		d1 = a * 2;
		d2 = 2 * (a + b);
		while (x != x1) {
			if (d < 0) {
				y += cy;
				d += d2;
			}
			else {
				d += d1;
			}
			x += cx;
			glBegin(GL_POINTS);
			glVertex2i(x, y);
			glEnd();
			glFlush();
		}
	}
	else {  //б�ʾ���ֵ>1
		d = a + 2 * b;
		d1 = b * 2;
		d2 = 2 * (a + b);
		while (y != y1) {
			if (d < 0) {
				d += d1;
			}
			else {
				x += cx;
				d += d2;
			}
			y += cy;
			glBegin(GL_POINTS);
			glVertex2i(x, y);
			glEnd();
			glFlush();
		}
		
	}
}

void bresenham_line(int x0,int y0,int x1,int y1)
{
	int dx = x1 - x0;
	int dy = y1 - y0;
	int cx = dx > 0 ? 1 : -1;
	int cy = dy > 0 ? 1 : -1;
	int dx2 = dx * 2;
	int dy2 = dy * 2;
	if (abs(dx) > abs(dy)) { //k<=1
		int e = -dx;
		int x = x0;
		int y = y0;
		for (x = x0; x < x1; x += cx) {
			glBegin(GL_POINTS);
			glVertex2i(x, y);
			glEnd();
			glFlush();
			e = e + dy2;
			if (e > 0) {
				y += cy;
				e = e - dx2;
			}
		}
	}
	else { //k>1
		int e = -dy;
		int x = x0;
		int y = y0;
		for (y = y0; y < y1; y += cy) {
			glBegin(GL_POINTS);
			glVertex2i(x, y);
			glEnd();
			glFlush();
			e = e + dx2;
			if (e > 0) {
				x += cx;
				e = e - dy2;
			}
		}
	}
}


void display_line(void)
{
	glClear(GL_COLOR_BUFFER_BIT);
	glColor3f(0.0, 0.0, 0.0); //�����ɫ
	glPointSize(2);
	/*int x0 = 100, y0 = 0, x1 =100, y1 = 200; //k not exist
	int x2 = 0, y2 = 100, x3 = 200, y3 = 100;//k = 0
	int x4 = 0, y4 = 100, x5 = 70, y5 = 200; //|k| >1
	int x6 = 0, y6 = 100, x7 = 70, y7 = 0; 
	int x8 = 100, y8 = 100, x9 = 200, y9 = 170;//|k| <=1
	int x10 = 100, y10 = 100, x11 = 200, y11 = 30;
	/*dda_line(x0, y0, x1, y1);
	dda_line(x2, y2, x3, y3);
	dda_line(x4, y4, x5, y5);
	dda_line(x6, y6, x7, y7);
	dda_line(x8, y8, x9, y9);
	dda_line(x11, y11, x10, y10);*/
	
	/*midpoint_line(x0, y0, x1, y1);
	midpoint_line(x2, y2, x3, y3);
	midpoint_line(x4, y4, x5, y5);
	midpoint_line(x6, y6, x7, y7);
	midpoint_line(x8, y8, x9, y9);
	midpoint_line(x11, y11, x10, y10);*/

	/*bresenham_line(x0, y0, x1, y1);
	bresenham_line(x2, y2, x3, y3);
	bresenham_line(x4, y4, x5, y5);
	bresenham_line(x6, y6, x7, y7);
	bresenham_line(x8, y8, x9, y9);
	bresenham_line(x10, y10, x11, y11);*/

	int x0 = 0, y0 = 0, x1 =160, y1 = 100;
	dda_line(x0, y0, x1, y1);
	
	bresenham_line(x0, y0 + 10, x1, y1 + 10);
	
}
